%1
A=[2,-1;-2,-2];%A����
B=[2,-3;0,4];
C=eye(2,2);
D=A+B;
E=A.*B;
F=A*B;

%2
A=[1,2,1;4,2,-6;-1,0,2];
B=[1,2,3;1,1,1];
X=B/A;

%3�ҳ�����3�ı���
clc,clear
x=[];
l=1;
for i=1:100
    if rem(i,3)==0
        x(l)=i;
        l=l+1;
    end
end

clc,clear
x=[];
i=1;
l=1;
while i<=100
    if rem(i,3)==0
        x(l)=i;
        l=l+1;
    end
    i=i+1;
end

%4
t=0:pi/100:2*pi;
x=5*sin(t);
y=2*cos(t);
plot(x,y)

%5
x=-1:0.1:1;
y=x;
[X,Y]=meshgrid(x,y);
z=3-X.^2-Y.^2;
mesh(x,y,z) 

%�׳� for 
p=1;
for i=1:5
    p=p*i;
end
p
%�׳� while 
p=1;
i=1;
while i<=5
    p=p*i;
    i=i+1;
    
end