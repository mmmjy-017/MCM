p=1;
i=1;
while i<=5
    p=p*i;
    i=i+1;
    
end

