%zuoye1
x=[];
l=1;
for i=100:999
    j=fix(i/100);
    k=fix((i-100*j)/10);
    t=i-100*j-10*k;
    if j^3+t^3+k^3==i
        x(l)=i;
        l=l+1
    end
end

%��ҵ2
x=0:0.1*pi:2*pi;
y1=0.2*exp(-0.5*x).*cos(4*pi*x);
y2=2*exp(-0.5*x).*cos(pi*x);
plot(x,y1,'r',x,y2,'b')

%��ҵ3
x=0:0.1*pi:2*pi;
y=x;
[X,Y]=meshgrid(x,y);
z=sin(X+sin(Y))-X/10;
mesh(x,y,z)

%4�׳����
sum=0;
for i=1:3
    p=1;
    for j=1:i
        p=p*j;
    end
    sum=sum+p;
end