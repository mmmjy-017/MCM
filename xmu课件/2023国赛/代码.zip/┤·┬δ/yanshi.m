x=hanshu(1,2);
for i=0:0.1*pi:2*pi
    x=hanshu(i,i);
end
