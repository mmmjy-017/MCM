function [x,y]=hanshu(a,b)

x=sin(a);
y=cos(b)